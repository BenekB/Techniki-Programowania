﻿//{{NO_DEPENDENCIES}}
// Plik dołączany wygenerowany przez program Microsoft Visual C++.
// Używane przez: WINDA.rc

#define IDS_APP_TITLE			103

#define IDR_MAINFRAME			128
#define IDD_WINDA_DIALOG	102
#define IDD_ABOUTBOX			103
#define IDM_ABOUT				104
#define IDM_EXIT				105
#define IDI_WINDA			107
#define IDI_SMALL				108
#define IDC_WINDA			109
#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1

#define ID_BUTTON_4_4		201
#define ID_BUTTON_4_3		202
#define ID_BUTTON_4_2		203
#define ID_BUTTON_4_1		204
#define ID_BUTTON_4_0		205
#define ID_BUTTON_3_4		206
#define ID_BUTTON_3_3		207
#define ID_BUTTON_3_2		208
#define ID_BUTTON_3_1		209
#define ID_BUTTON_3_0		210
#define ID_BUTTON_2_4		211
#define ID_BUTTON_2_3		212
#define ID_BUTTON_2_2		213
#define ID_BUTTON_2_1		214
#define ID_BUTTON_2_0		215
#define ID_BUTTON_1_4		216
#define ID_BUTTON_1_3		217
#define ID_BUTTON_1_2		218
#define ID_BUTTON_1_1		219
#define ID_BUTTON_1_0		220
#define ID_BUTTON_0_4		221
#define ID_BUTTON_0_3		222
#define ID_BUTTON_0_2		223
#define ID_BUTTON_0_1		224
#define ID_BUTTON_0_0		225

#define TIMER_1					1001
#define TIMER_2					1002
#define TIMER_3					1003
#endif
// Następne wartości domyślne dla nowych obiektów
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
