﻿#pragma once

// Dołączenie pliku SDKDDKVer.h definiuje najwyższą dostępną platformę systemu Windows.

// Jeśli chcesz skompilować aplikację dla wcześniejszej platformy systemu Windows, dołącz plik WinSDKVer.h i
// ustaw makro _WIN32_WINNT na platformę, którą chcesz obsługiwać, przed dołączeniem pliku SDKDDKVer.h.

#include <SDKDDKVer.h>
