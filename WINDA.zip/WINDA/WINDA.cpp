﻿// WINDA.cpp : Definiuje punkt wejścia dla aplikacji.
//

#include "stdafx.h"
#include "WINDA.h"
#include <Windows.h>
#include <vector>
#include <objidl.h>
#include <gdiplus.h>
using namespace std;
using namespace Gdiplus;
#pragma comment (lib,"Gdiplus.lib")


#define MAX_LOADSTRING 100

// Zmienne globalne:
HINSTANCE hInst;                                // bieżące wystąpienie
WCHAR szTitle[MAX_LOADSTRING];                  // Tekst paska tytułu
WCHAR szWindowClass[MAX_LOADSTRING];            // nazwa klasy okna głównego


// Przekaż dalej deklaracje funkcji dołączone w tym module kodu:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);


HWND HWND_BUTTON;
PAINTSTRUCT painstruct;
HDC hdc;
RECT area_elevator = { 15, 15, 295, 725};			//obszar windy - prostokat w ktorym sie porusza
RECT area_zero_floor = { 315, 615, 555, 715 };		//obszary kolejnych pieter
RECT area_first_floor = { 315, 475, 555, 575 };
RECT area_second_floor = { 315, 335, 555, 435 };
RECT area_third_floor = { 315, 195, 555, 295 };
RECT area_fourth_floor = { 315, 55, 555, 155 };

int help = 0;			//jest to glowna zmienna sluzaca do animacji windy
int zmiana = 2;			//zmiana polozenia windy: jezeli 2 - jedzie w dol; jezeli -2 - jedzie w gore
int change;
bool czy_zatrzyma;		
bool go_down = true;


vector <int> winda;				//kolejne wektory, ktore przechowuja informacje o tym, kto jest aktualnie w windzie lub na pietrze
vector <int> level_0;
vector <int> level_1;
vector <int> level_2;
vector <int> level_3;
vector <int> level_4;


void elevator(HDC);				//glowna funkcja zarzadzajaca dzialaniem windy
void elevator_floor(HDC);		//rysuje ludzi (prostokaty) w windzie
void zero_floor(HDC);			//kolejne 5 funkcji odpowiada za rysowanie ludzi (prostokatow) na kolejnych pietrach
void first_floor(HDC);
void second_floor(HDC);
void third_floor(HDC);
void fourth_floor(HDC);
void usun_z_windy(int);				//usuwa ludzi z windy jak wychodza
void usun_z_level_1(int ktora);		//trzy kolejne usuwaja ludzi z poszczegolnych pieter jak wchodza do windy
void usun_z_level_2(int ktora);
void usun_z_level_3(int ktora);



VOID OnPaint(HDC hdc)			//rysuje stale elementy ekspozycji na samym poczatku
{
	Graphics graphics(hdc);
	Pen      pen_1(Color(255, 0, 0, 255), 4);				//inicjuje trzy rodzaje pendzli
	Pen      pen_2(Color(255, 0, 255, 0), 2);
	Pen		 pen_3(Color(255, 0, 0, 0), 3);

	graphics.DrawRectangle(&pen_1, 10, 10, 290, 720);		//rysuje prostokat, w ktorym porusza sie winda
	graphics.DrawRectangle(&pen_2, 10, 10, 290, 720);

	graphics.DrawLine(&pen_3, 310, 160, 600, 160);			//rysuje platformy na kazdym pietrze
	graphics.DrawLine(&pen_3, 310, 300, 600, 300);
	graphics.DrawLine(&pen_3, 310, 440, 600, 440);
	graphics.DrawLine(&pen_3, 310, 580, 600, 580);
	graphics.DrawLine(&pen_3, 310, 720, 600, 720);

	SolidBrush  brush(Color(255, 0, 0, 0));					//ustawiam kolor, czcionke, wielkosc napisu
	FontFamily  fontFamily(L"Times New Roman");
	Font        font(&fontFamily, 100, FontStyleRegular, UnitPixel);

	PointF      point4(630, 50);							//struktura punktu, ktora potem wykorzystuje, zeby od tego punktu wstawiac napis
	PointF      point3(630, 190);
	PointF      point2(630, 330);
	PointF      point1(630, 470);
	PointF      point0(630, 610);

	graphics.DrawString(L"4", -1, &font, point4, &brush);	//wypisuje numery pieter
	graphics.DrawString(L"3", -1, &font, point3, &brush);
	graphics.DrawString(L"2", -1, &font, point2, &brush);
	graphics.DrawString(L"1", -1, &font, point1, &brush);
	graphics.DrawString(L"0", -1, &font, point0, &brush);
}



void elevator(HDC hdc, HWND hWnd)		//glowna funkcja zarzadzajaca dzialaniem windy
{
	czy_zatrzyma = true;				//daje informacje, czy sie zatrzymac, czy nie na danym pietrze

	if (help != 0 && help != 140 && help != 280 && help != 420 && help != 560 && zmiana != 0)		//jezeli jest pomiedzy pietrami, to ma sie poruszac dalej tak jak sie poruszala
		elevator_floor(hdc);														//rysuje ludzi w windzie


	else if (help == 0)		//jezeli jest na czwartym pietrze
	{
		KillTimer(hWnd, TIMER_1);						//wylaczam podstawowy timer
		SetTimer(hWnd, TIMER_2, 2000, NULL);			//ustawiam timer do czekania 2 sekund na danym pietrze


		for (int i = winda.size(); i > 0; i--)			//sprawdzam, czy ludzie chcieli wysiasc na tym pietrze
			if (winda[i - 1] == 4)						//jezeli chcieli wysiasc na tym pietrze
			{
				usun_z_windy(i - 1);					//to ich usuwam z windy
			}


		for (int i = winda.size(); i < 5; i++)			//dla każdego pustego miejsce w windzie
		{
			if (level_4.size() > 0)						//jezeli na czwartym pietrze ktos jest
			{
				winda.push_back(level_4[0]);			//ten ktos wsiada do windy
				level_4.erase(level_4.begin());			//wiec usuwam go z czwartego pietra, bo jest juz w windzie
			}
		}

		zmiana = 2;										//jezeli jest na czwartym pietrze, to znaczy, że jechała do gory, 
														//nie moze dalej jechac do gory, wiec zmianiam kierunek jazdy na dol

		elevator_floor(hdc);


		if (winda.size() == 0 && level_0.size() == 0 && level_1.size() == 0 && level_2.size() == 0 && level_3.size() == 0 && level_4.size() == 0 && go_down)
		{
			KillTimer(hWnd, TIMER_1);					//jezeli na wszystkich pietrach jest pusto, to ma poczekac 5 sekund i jechac na dol
			KillTimer(hWnd, TIMER_2);
			SetTimer(hWnd, TIMER_3, 5000, NULL);
			go_down = false;							//sluzy do tego, aby winda nie czekala na kazdym pietrze 5 sekund, tylko jechala prosto na dol
		}
	}


	else if (help == 140)		//jezeli jest na trzecim pietrze
	{
		for (int i = winda.size(); i > 0; i--)					//tak jak dla pietra czwartego 
			if (winda[i - 1] == 3)
			{
				usun_z_windy(i - 1);

				if (czy_zatrzyma)								
				{
					KillTimer(hWnd, TIMER_1);
					SetTimer(hWnd, TIMER_2, 2000, NULL);
					czy_zatrzyma = false;
					go_down = true;
				}
			}
		
		if (winda.size() != 0)									//jeżeli ktos jest w windzie
		{
			for (int i = winda.size(); i < 5; i++)				//dla kazdego wolnego miejsce w windzie
			{
				if (zmiana == 2)								//jezeli jechala w dol, to zabiera ludzi, ktorzy chca jechac na dol
				{
					for (int j = 0; j < level_3.size(); j++)	//sprawdzam wszystkie osoby z trzeciego pietra
					{
						if (level_3[j] < 3)						//jezeli chce jechac z kierunkiem jazdy
						{
							winda.push_back(level_3[j]);		//zabieram czlowieka do windy	
							usun_z_level_3(j);					//usuwam go z trzeciego pietra

							if (czy_zatrzyma)
							{
								KillTimer(hWnd, TIMER_1);
								SetTimer(hWnd, TIMER_2, 2000, NULL);
								czy_zatrzyma = false;
								go_down = true;
							}

							break;								//koncze sprawdzanie trzeciego pietra, bo znalazlem osobe na dane miejsce w windzie
						}
					}
				}
				else if (zmiana == -2)							//jezeli jechala do gory, to zabiera ludzi, ktorzy chca jechac do gory
				{
					for (int j = 0; j < level_3.size(); j++)	//analogicznie jak powyżej
					{
						if (level_3[j] == 4)
						{
							winda.push_back(level_3[j]);
							usun_z_level_3(j);

							if (czy_zatrzyma)
							{
								KillTimer(hWnd, TIMER_1);
								SetTimer(hWnd, TIMER_2, 2000, NULL);
								czy_zatrzyma = false;
								go_down = true;
							}

							break;
						}
					}

				}

			}
		}

		else if (level_3.size() > 0)								//jezeli nie ma nikogo w windzie, a ktos jest na trzecim pietrze
		{
			if (czy_zatrzyma)
			{
				KillTimer(hWnd, TIMER_1);
				SetTimer(hWnd, TIMER_2, 2000, NULL);
				czy_zatrzyma = false;
				go_down = true;
			}

			if (level_3[0] == 4)								//jezeli pierwsza osoba w kolejce chce jechac do gory, to zabieram
			{													//te ktore jada do gory
				for (int i = 0; i < 5; i++)						//dla kazdego miejsca w windzie
				{
					for (int j = 0; j < level_3.size(); j++)	//sprawdzam, czy ktos z trzeciego pietra tez chce jechac do gory
					{
						if (level_3[j] == 4)					//jezeli ktos chce
						{
							winda.push_back(level_3[j]);		//wsadzam go do windy
							usun_z_level_3(j);					//i usuwam z trzeciego pietra
							break;								//obsadzilem to konkretne miejsce w windzie, wiec koncze najblizsza petle; zaczynam szukac dla kolejnego miejsca w windzie
						}
					}
				}
			}
			else if (level_3[0] < 3)							//jezeli pierwsza osoba w kolejce chce jechac na dol, to zabieram
			{													//osoby, ktore chca jechac na dol
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < level_3.size(); j++)	//analogicznie jak powyżej
					{
						if (level_3[j] < 3)
						{
							winda.push_back(level_3[j]);
							usun_z_level_3(j);
							break;
						}
					}
				}
			}
		}

		if (winda.size() == 0)				//jezeli winda jest pusta
		{
			if (level_4.size() == 0)		//i pietra powyzej sa puste
				zmiana = 2;					//to  ma jechac na dol
			else							//w przeciwnym wypadku
				zmiana = -2;				//ma jechac po ludzi w wyzszych pieter
		}
		else								//jezeli winda nie jest pusta
		{
			if (winda[0] == 4)				//jezeli pierwsza osoba chce jechac do gory
				zmiana = -2;				//winda jedzie do gory
			else							//jezeli pierwsza osoba chce jechac na dol
				zmiana = 2;					//winda jedzie na dol
		}

		if (!czy_zatrzyma)
			elevator_floor(hdc);

		if (winda.size() == 0 && level_0.size() == 0 && level_1.size() == 0 && level_2.size() == 0 && level_3.size() == 0 && level_4.size() == 0 && go_down)
		{
			KillTimer(hWnd, TIMER_1);
			KillTimer(hWnd, TIMER_2);
			SetTimer(hWnd, TIMER_3, 5000, NULL);
			go_down = false;
		}
	}


	else if (help == 280)		//jezeli winda jest na drugim pietrze - dzialanie analogiczne jak dla pietra trzeciego
	{
		for (int i = winda.size(); i > 0; i--)
			if (winda[i - 1] == 2)
			{
				usun_z_windy(i - 1);

				if (czy_zatrzyma)
				{
					KillTimer(hWnd, TIMER_1);
					SetTimer(hWnd, TIMER_2, 2000, NULL);
					czy_zatrzyma = false;
					go_down = true;
				}
			}

		if (winda.size() != 0)
		{
			for (int i = winda.size(); i < 5; i++)
			{
				if (zmiana == 2)
				{
					for (int j = 0; j < level_2.size(); j++)
					{
						if (level_2[j] < 2)
						{
							winda.push_back(level_2[j]);
							usun_z_level_2(j);
							break;

							if (czy_zatrzyma)
							{
								KillTimer(hWnd, TIMER_1);
								SetTimer(hWnd, TIMER_2, 2000, NULL);
								czy_zatrzyma = false;
								go_down = true;
							}
						}
					}
				}
				else if (zmiana == -2)
				{
					for (int j = 0; j < level_2.size(); j++)
					{
						if (level_2[j] > 2)
						{
							winda.push_back(level_2[j]);
							usun_z_level_2(j);
							break;

							if (czy_zatrzyma)
							{
								KillTimer(hWnd, TIMER_1);
								SetTimer(hWnd, TIMER_2, 2000, NULL);
								czy_zatrzyma = false;
								go_down = true;
							}
						}
					}

				}
			}
		}

		else if (level_2.size() > 0)
		{
			if (czy_zatrzyma)
			{
				KillTimer(hWnd, TIMER_1);
				SetTimer(hWnd, TIMER_2, 2000, NULL);
				czy_zatrzyma = false;
				go_down = true;
			}

			if (level_2[0] > 2)
			{
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < level_2.size(); j++)
					{
						if (level_2[j] > 2)
						{
							winda.push_back(level_2[j]);
							usun_z_level_2(j);
							break;
						}
					}
				}
			}
			else if (level_2[0] < 2)
			{
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < level_2.size(); j++)
					{
						if (level_2[j] < 2)
						{
							winda.push_back(level_2[j]);
							usun_z_level_2(j);
							break;
						}
					}
				}

			}
		}

		if (winda.size() == 0)
		{
			if (level_3.size() == 0 && level_4.size() == 0)
				zmiana = 2;
			else
				zmiana = -2;
		}
		else
		{
			if (winda[0] > 2)
				zmiana = -2;
			else
				zmiana = 2;
		}

		if (!czy_zatrzyma)
			elevator_floor(hdc);

		if (winda.size() == 0 && level_0.size() == 0 && level_1.size() == 0 && level_2.size() == 0 && level_3.size() == 0 && level_4.size() == 0 && go_down)
		{
			KillTimer(hWnd, TIMER_1);
			KillTimer(hWnd, TIMER_2);
			SetTimer(hWnd, TIMER_3, 5000, NULL);
			go_down = false;
		}
	}


	else if (help == 420)		//jezeli jest na pierwszym pietrze - zasada dzialania analogicznie jak dla pietra trzeciego
	{
		for (int i = winda.size(); i > 0; i--)
			if (winda[i - 1] == 1)
			{
				usun_z_windy(i - 1);
		
				if (czy_zatrzyma)
				{
					KillTimer(hWnd, TIMER_1);
					SetTimer(hWnd, TIMER_2, 2000, NULL);
					czy_zatrzyma = false;
					go_down = true;
				}
			}

		if (winda.size() != 0)
		{
			for (int i = winda.size(); i < 5; i++)
			{
				if (zmiana == 2)
				{
					for (int j = 0; j < level_1.size(); j++)
					{
						if (level_1[j] == 0)
						{
							winda.push_back(level_1[j]);
							usun_z_level_1(j);
							break;

							if (czy_zatrzyma)
							{
								KillTimer(hWnd, TIMER_1);
								SetTimer(hWnd, TIMER_2, 2000, NULL);
								czy_zatrzyma = false;
								go_down = true;
							}
						}
					}
				}
				else if (zmiana == -2)
				{
					for (int j = 0; j < level_1.size(); j++)
					{
						if (level_1[j] > 1)
						{
							winda.push_back(level_1[j]);
							usun_z_level_1(j);
							break;

							if (czy_zatrzyma)
							{
								KillTimer(hWnd, TIMER_1);
								SetTimer(hWnd, TIMER_2, 2000, NULL);
								czy_zatrzyma = false;
								go_down = true;
							}
						}
					}

				}
			}
		}

		else if (level_1.size() > 0)
		{
			if (czy_zatrzyma)
			{
				KillTimer(hWnd, TIMER_1);
				SetTimer(hWnd, TIMER_2, 2000, NULL);
				czy_zatrzyma = false;
				go_down = true;
			}

			if (level_1[0] > 1)
			{
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < level_1.size(); j++)
					{
						if (level_1[j] > 1)
						{
							winda.push_back(level_1[j]);
							usun_z_level_1(j);
							break;
						}
					}
				}
			}
			else if (level_1[0] < 1)
			{
				for (int i = 0; i < 5; i++)
				{
					for (int j = 0; j < level_1.size(); j++)
					{
						if (level_1[j] < 1)
						{
							winda.push_back(level_1[j]);
							usun_z_level_1(j);
							break;
						}
					}
				}

			}
		}

		if (winda.size() == 0)
		{
			if (level_4.size() == 0 && level_3.size() == 0 && level_2.size() == 0)
				zmiana = 2;
			else
				zmiana = -2;
		}
		else
		{
			if (winda[0] > 1)
				zmiana = -2;
			else
				zmiana = 2;
		}

		if (!czy_zatrzyma)
			elevator_floor(hdc);

		if (winda.size() == 0 && level_0.size() == 0 && level_1.size() == 0 && level_2.size() == 0 && level_3.size() == 0 && level_4.size() == 0 && go_down)
		{
			KillTimer(hWnd, TIMER_1);
			KillTimer(hWnd, TIMER_2);
			SetTimer(hWnd, TIMER_3, 5000, NULL);
			go_down = false;
		}
	}


	else if (help == 560)		//jezeli jest na parterze - dzialanie analogicze jak dla pietra czwartego
	{
		for (int i = winda.size(); i > 0; i--)
			if (winda[i - 1] == 0)
			{
				usun_z_windy(i - 1);

				if (czy_zatrzyma)
				{
					KillTimer(hWnd, TIMER_1);
					SetTimer(hWnd, TIMER_2, 2000, NULL);
					czy_zatrzyma = false;
				}
			}


		for (int i = winda.size(); i < 5; i++)
		{
			if (czy_zatrzyma)
			{
				KillTimer(hWnd, TIMER_1);
				SetTimer(hWnd, TIMER_2, 2000, NULL);
				czy_zatrzyma = false;
			}

			if (level_0.size() > 0)
			{
				winda.push_back(level_0[0]);
				level_0.erase(level_0.begin());
			}
		}
		
		if ((level_0.size() + level_1.size() + level_2.size() + level_3.size() + level_4.size() + winda.size()) == 0)
		{
			zmiana = 0;				//jezeli wszystkie pietra sa puste, to ma zostac na zerowym pietrze, czyli sie nie ruszac
		}
		else
			zmiana = -2;			//jezeli nie sa puste, to jedzie do gory

		elevator_floor(hdc);
	}
}



void elevator_floor(HDC hdc)	//rysuje ludzi (prostokaty) w windzie	
{
	Graphics	graphics(hdc);
	Pen			pen(Color(255, 255, 0, 255), 3);						//ustawim pendzel, czcionke, jej wlasciwosci
	Pen			pen_w(Color(255, 0, 0, 255), 3);
	SolidBrush  brush(Color(255, 0, 0, 0));
	FontFamily  fontFamily(L"Times New Roman");
	Font        font(&fontFamily, 50, FontStyleRegular, UnitPixel);

	change = 0;			//sluzy do przesuniecia kolejnych osob wzgledem sciany windy

	graphics.DrawRectangle(&pen_w, 20, 20 + help, 270, 140);			//rysuje glowny prostokat windy

	for (int i = 0; i < winda.size(); i++)			//dla kazdego czlowieka, ktory jest w windzie
	{
		PointF	point(30 + change, 70 + help);								//tworze punkt, od ktorego ma zaczac pisac numer pietra uwzgledniajac przesuniecie
		
		graphics.DrawRectangle(&pen, 30 + change, 60 + help, 40, 90);		//rysuje prostokąt

		switch (winda[i])													//w zaleznosci od tego na ktore pietro czlowiek chce jechac wypisuje rozne liczby
		{
		case 0:
			graphics.DrawString(L"0", -1, &font, point, &brush); break;
		case 1:
			graphics.DrawString(L"1", -1, &font, point, &brush); break;
		case 2:
			graphics.DrawString(L"2", -1, &font, point, &brush); break;
		case 3:
			graphics.DrawString(L"3", -1, &font, point, &brush); break;
		case 4:
			graphics.DrawString(L"4", -1, &font, point, &brush); break;
		}

		change += 45;			//o tyle przesuwam kolejnych ludzi wzgledem pierwszego
	}
}



void zero_floor(HDC hdc)		//rysuje ludzi na parterze - dziala analogicznie jak dla windy
{
	Graphics	graphics(hdc);
	Pen			pen(Color(255, 255, 0, 255), 3);
	SolidBrush  brush(Color(255, 0, 0, 0));
	FontFamily  fontFamily(L"Times New Roman");
	Font        font(&fontFamily, 50, FontStyleRegular, UnitPixel);

	change = 0;

	for (int i = 0; i < level_0.size(); i++)
	{
		PointF		point(320 + change, 630);

		graphics.DrawRectangle(&pen, 320 + change, 620, 40, 90);

		switch (level_0[i])
		{
		case 4:
			graphics.DrawString(L"4", -1, &font, point, &brush); break;
		case 1:
			graphics.DrawString(L"1", -1, &font, point, &brush); break;
		case 2:
			graphics.DrawString(L"2", -1, &font, point, &brush); break;
		case 3:
			graphics.DrawString(L"3", -1, &font, point, &brush); break;
		}

		change += 45;
	}
}



void first_floor(HDC hdc)		//rysuje ludzi na pierwszym pietrze - dziala analogicznie jak dla windy
{
	Graphics	graphics(hdc);
	Pen			pen(Color(255, 255, 0, 255), 3);
	SolidBrush  brush(Color(255, 0, 0, 0));
	FontFamily  fontFamily(L"Times New Roman");
	Font        font(&fontFamily, 50, FontStyleRegular, UnitPixel);

	change = 0;

	for (int i = 0; i < level_1.size(); i++)
	{
		PointF		point(320 + change, 490);

		graphics.DrawRectangle(&pen, 320 + change, 480, 40, 90);

		switch (level_1[i])
		{
		case 0:
			graphics.DrawString(L"0", -1, &font, point, &brush); break;
		case 4:
			graphics.DrawString(L"4", -1, &font, point, &brush); break;
		case 2:
			graphics.DrawString(L"2", -1, &font, point, &brush); break;
		case 3:
			graphics.DrawString(L"3", -1, &font, point, &brush); break;
		}

		change += 45;
	}
}



void second_floor(HDC hdc)			//rysuje ludzi na drugim pietrze - dziala analogicznie jak dla windy
{
	Graphics	graphics(hdc);
	Pen			pen(Color(255, 255, 0, 255), 3);
	SolidBrush  brush(Color(255, 0, 0, 0));
	FontFamily  fontFamily(L"Times New Roman");
	Font        font(&fontFamily, 50, FontStyleRegular, UnitPixel);

	change = 0;

	for (int i = 0; i < level_2.size(); i++)
	{
		PointF		point(320 + change, 350);

		graphics.DrawRectangle(&pen, 320 + change, 340, 40, 90);

		switch (level_2[i])
		{
		case 0:
			graphics.DrawString(L"0", -1, &font, point, &brush); break;
		case 1:
			graphics.DrawString(L"1", -1, &font, point, &brush); break;
		case 4:
			graphics.DrawString(L"4", -1, &font, point, &brush); break;
		case 3:
			graphics.DrawString(L"3", -1, &font, point, &brush); break;
		}

		change += 45;
	}
}



void third_floor(HDC hdc)			//rysuje ludzi na trzecim pietrze - dziala analogicznie jak dla windy
{
	Graphics	graphics(hdc);
	Pen			pen(Color(255, 255, 0, 255), 3);
	SolidBrush  brush(Color(255, 0, 0, 0));
	FontFamily  fontFamily(L"Times New Roman");
	Font        font(&fontFamily, 50, FontStyleRegular, UnitPixel);

	change = 0;

	for (int i = 0; i < level_3.size(); i++)
	{
		PointF		point(320 + change, 210);

		graphics.DrawRectangle(&pen, 320 + change, 200, 40, 90);

		switch (level_3[i])
		{
		case 0:
			graphics.DrawString(L"0", -1, &font, point, &brush); break;
		case 1:
			graphics.DrawString(L"1", -1, &font, point, &brush); break;
		case 2:
			graphics.DrawString(L"2", -1, &font, point, &brush); break;
		case 4:
			graphics.DrawString(L"4", -1, &font, point, &brush); break;
		}

		change += 45;
	}
}



void fourth_floor(HDC hdc)			//rysuje ludzi na czwartym pietrze - dziala analogicznie jak dla windy
{
	Graphics	graphics(hdc);
	Pen			pen(Color(255, 255, 0, 255), 3);
	SolidBrush  brush(Color(255, 0, 0, 0));
	FontFamily  fontFamily(L"Times New Roman");
	Font        font(&fontFamily, 50, FontStyleRegular, UnitPixel);

	change = 0;

	for (int i = 0; i < level_4.size(); i++)
	{
		PointF		point(320 + change, 70);

		graphics.DrawRectangle(&pen, 320 + change, 60, 40, 90);

		switch (level_4[i])
		{
		case 0:
			graphics.DrawString(L"0", -1, &font, point, &brush); break;
		case 1:
			graphics.DrawString(L"1", -1, &font, point, &brush); break;
		case 2:
			graphics.DrawString(L"2", -1, &font, point, &brush); break;
		case 3:
			graphics.DrawString(L"3", -1, &font, point, &brush); break;
		}
		
		change += 45;
	}
}



void repaintWindow(HWND hWnd, HDC& hdc, PAINTSTRUCT& ps, RECT* drawArea, int ktory)				//podstawowa funkcja do odswiezania ekranu i zmian na ekranie
{
	InvalidateRect(hWnd, drawArea, TRUE);			//okreslamy w jakim obszarze chcemy rysowac
	hdc = BeginPaint(hWnd, &ps);
	

	switch (ktory)				//w zaleznosci od wartosci zmiennej ktory, rysuje okreslony obszar okna 
	{
	case 1:
		elevator(hdc, hWnd); break;
	case 2:
		fourth_floor(hdc); break;
	case 3:
		zero_floor(hdc); break;
	case 4:
		first_floor(hdc); break;
	case 5:
		second_floor(hdc); break;
	case 6:
		third_floor(hdc); break;
	}

	EndPaint(hWnd, &ps);
}



int OnCreate(HWND window)						//ustawiam tu timer, ktory jest potrzebny przy tworzeniu animacji windy
{
	SetTimer(window, TIMER_1, 50, 0);			//ustawiam interwal czasowy na 50 milisekund
	return 0;
}



void usun_z_windy(int ktora)					//usuwa ludzi z windy jak wychodza
{
	while (ktora + 1 < winda.size())			//petla sluzy do przesuniecia calego vectora o jeden w lewo zaczynajac od elementu numer ktora + 1
	{
		winda[ktora] = winda[ktora + 1];		
		ktora++;
	}

	winda.pop_back();							//nastepnie usuwam ostatni element vectora winda
}



void usun_z_level_3(int ktora)					//usuwa element z vectora level_3 - dziala analogocznia jak dla windy
{
	while (ktora + 1 < level_3.size())
	{
		level_3[ktora] = level_3[ktora + 1];
		ktora++;
	}

	level_3.pop_back();
}



void usun_z_level_2(int ktora)					//usuwa element z vectora level_2 - dziala analogocznia jak dla windy
{
	while (ktora + 1 < level_2.size())
	{
		level_2[ktora] = level_2[ktora + 1];
		ktora++;
	}

	level_2.pop_back();
}



void usun_z_level_1(int ktora)					//usuwa element z vectora level_1 - dziala analogocznia jak dla windy
{
	while (ktora + 1 < level_1.size())
	{
		level_1[ktora] = level_1[ktora + 1];
		ktora++;
	}

	level_1.pop_back();
}



int APIENTRY wWinMain(_In_ HINSTANCE hInstance,						//glowna funkcja WinAPI
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
	GdiplusStartupInput gdiplusStartupInput;						//kolejne trzy linijki sluza do uzytkowania GDI+
	ULONG_PTR           gdiplusToken;
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);


    // Inicjuj ciągi globalne
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINDA, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Wykonaj inicjowanie aplikacji:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WINDA));

    MSG msg;

    // Główna pętla komunikatów:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

	GdiplusShutdown(gdiplusToken);							//rowniez sluzy do obslugi GDI+
    return (int) msg.wParam;
}



//
//  FUNKCJA: MyRegisterClass()
//
//  PRZEZNACZENIE: Rejestruje klasę okna.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WINDA));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_WINDA);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}



//
//   FUNKCJA: InitInstance(HINSTANCE, int)
//
//   PRZEZNACZENIE: Zapisuje dojście wystąpienia i tworzy okno główne
//
//   KOMENTARZE:
//
//        W tej funkcji dojście wystąpienia jest zapisywane w zmiennej globalnej i
//        jest tworzone i wyświetlane okno główne programu.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)					//tu przede wszystkim tworze przyciski
{
   hInst = hInstance; // Przechowuj dojście wystąpienia w naszej zmiennej globalnej

   HWND hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);


   HWND_BUTTON = CreateWindow(TEXT("button"),
	   TEXT("4"),								//napis na guziku
	   WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 30,									//odległosc od lewej i od gory
	   25, 25,									//szerokosc i wysokosc
	   hWnd,									//tak ma po prostu byc
	   (HMENU)ID_BUTTON_4_4,					//id przycisku - ID sa zdefiniowane w pliku Resource.h
	   hInstance, NULL);						//nie ruszac i nie zmieniac
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("3"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,			//przyciski dla czwartego pietra
	   575, 55, 25, 25, hWnd, (HMENU)ID_BUTTON_4_3, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("2"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 80, 25, 25, hWnd, (HMENU)ID_BUTTON_4_2, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("1"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 105, 25, 25, hWnd, (HMENU)ID_BUTTON_4_1, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("0"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 130, 25, 25, hWnd, (HMENU)ID_BUTTON_4_0, hInstance, NULL);


   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("4"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,			//przyciski dla trzeciego pietra
	   575, 170, 25, 25, hWnd, (HMENU)ID_BUTTON_3_4, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("3"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 195, 25, 25, hWnd, (HMENU)ID_BUTTON_3_3, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("2"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 220, 25, 25, hWnd, (HMENU)ID_BUTTON_3_2, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("1"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 245, 25, 25, hWnd, (HMENU)ID_BUTTON_3_1, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("0"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 270, 25, 25, hWnd, (HMENU)ID_BUTTON_3_0, hInstance, NULL);


   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("4"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,			//przyciski dla drugiego pietra
	   575, 310, 25, 25, hWnd, (HMENU)ID_BUTTON_2_4, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("3"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 335, 25, 25, hWnd, (HMENU)ID_BUTTON_2_3, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("2"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 360, 25, 25, hWnd, (HMENU)ID_BUTTON_2_2, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("1"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 385, 25, 25, hWnd, (HMENU)ID_BUTTON_2_1, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("0"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 410, 25, 25, hWnd, (HMENU)ID_BUTTON_2_0, hInstance, NULL);


   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("4"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,			//przyciski dla pierwszego pietra
	   575, 450, 25, 25, hWnd, (HMENU)ID_BUTTON_1_4, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("3"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 475, 25, 25, hWnd, (HMENU)ID_BUTTON_1_3, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("2"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 500, 25, 25, hWnd, (HMENU)ID_BUTTON_1_2, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("1"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 525, 25, 25, hWnd, (HMENU)ID_BUTTON_1_1, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("0"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 550, 25, 25, hWnd, (HMENU)ID_BUTTON_1_0, hInstance, NULL);


   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("4"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,			//przyciski dla parteru
	   575, 590, 25, 25, hWnd, (HMENU)ID_BUTTON_0_4, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("3"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 615, 25, 25, hWnd, (HMENU)ID_BUTTON_0_3, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("2"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 640, 25, 25, hWnd, (HMENU)ID_BUTTON_0_2, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("1"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 665, 25, 25, hWnd, (HMENU)ID_BUTTON_0_1, hInstance, NULL);
   HWND_BUTTON = CreateWindow(TEXT("button"), TEXT("0"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
	   575, 690, 25, 25, hWnd, (HMENU)ID_BUTTON_0_0, hInstance, NULL);


   OnCreate(hWnd);						//ta funkcja ustawia timer

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}



//
//  FUNKCJA: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PRZEZNACZENIE: Przetwarza komunikaty dla okna głównego.
//
//  WM_COMMAND  - przetwarzaj menu aplikacji
//  WM_PAINT    - Maluj okno główne
//  WM_DESTROY  - opublikuj komunikat o wyjściu i wróć
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)				//glowna petla komunikatow
{
	PAINTSTRUCT ps;				//to i nastepna linijka potrzebne do rysowania
	HDC hdc;

    switch (message)
    {
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);

            switch (wmId)						//glowny switch do odbierania sygnalow z przyciskow
            {
			case ID_BUTTON_0_1:
					level_0.push_back(1); repaintWindow(hWnd, hdc, ps, &area_zero_floor, 3); break;		//dla danego przycisku odswierzam grafike na danym pietrze
			case ID_BUTTON_0_2:
					level_0.push_back(2); repaintWindow(hWnd, hdc, ps, &area_zero_floor, 3); break;
			case ID_BUTTON_0_3:
					level_0.push_back(3); repaintWindow(hWnd, hdc, ps, &area_zero_floor, 3); break;
			case ID_BUTTON_0_4:
					level_0.push_back(4); repaintWindow(hWnd, hdc, ps, &area_zero_floor, 3); break;
			case ID_BUTTON_1_0:
					level_1.push_back(0); repaintWindow(hWnd, hdc, ps, &area_first_floor, 4); break;
			case ID_BUTTON_1_2:
					level_1.push_back(2); repaintWindow(hWnd, hdc, ps, &area_first_floor, 4); break;
			case ID_BUTTON_1_3:
					level_1.push_back(3); repaintWindow(hWnd, hdc, ps, &area_first_floor, 4); break;
			case ID_BUTTON_1_4:
					level_1.push_back(4); repaintWindow(hWnd, hdc, ps, &area_first_floor, 4); break;
   			case ID_BUTTON_2_0:
					level_2.push_back(0); repaintWindow(hWnd, hdc, ps, &area_second_floor, 5); break;
   			case ID_BUTTON_2_1:
					level_2.push_back(1); repaintWindow(hWnd, hdc, ps, &area_second_floor, 5); break;
   			case ID_BUTTON_2_3:
					level_2.push_back(3); repaintWindow(hWnd, hdc, ps, &area_second_floor, 5); break;
   			case ID_BUTTON_2_4:
					level_2.push_back(4); repaintWindow(hWnd, hdc, ps, &area_second_floor, 5); break;
     		case ID_BUTTON_3_0:
					level_3.push_back(0); repaintWindow(hWnd, hdc, ps, &area_third_floor, 6); break;
     		case ID_BUTTON_3_1:
					level_3.push_back(1); repaintWindow(hWnd, hdc, ps, &area_third_floor, 6); break;
     		case ID_BUTTON_3_2:
					level_3.push_back(2); repaintWindow(hWnd, hdc, ps, &area_third_floor, 6); break;
     		case ID_BUTTON_3_4:
					level_3.push_back(4); repaintWindow(hWnd, hdc, ps, &area_third_floor, 6); break;
     		case ID_BUTTON_4_0:
					level_4.push_back(0); repaintWindow(hWnd, hdc, ps, &area_fourth_floor, 2); break;
     		case ID_BUTTON_4_1:
					level_4.push_back(1); repaintWindow(hWnd, hdc, ps, &area_fourth_floor, 2); break;
     		case ID_BUTTON_4_2:
					level_4.push_back(2); repaintWindow(hWnd, hdc, ps, &area_fourth_floor, 2); break;
     		case ID_BUTTON_4_3:
					level_4.push_back(3); repaintWindow(hWnd, hdc, ps, &area_fourth_floor, 2); break;

            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;


    case WM_PAINT:
        {
            hdc = BeginPaint(hWnd, &ps);
			OnPaint(hdc);							//tutaj wykonuje rysowanie poczatkowe - to co pojawia sie od poczatku i zostaje do konca
            EndPaint(hWnd, &ps);
        }
        break;


    case WM_DESTROY:
        PostQuitMessage(0);
        break;


	case WM_TIMER:
		switch (wParam) 
		{
		case TIMER_1:																			//na sygnal z timera

			repaintWindow(hWnd, hdc, ps, &area_elevator, 1);									//rysuje winde z ludzmi

			if (help == 0)	repaintWindow(hWnd, hdc, ps, &area_fourth_floor, 2);				//jezeli jest na jakims pietrze, to to pietro odswierza
			else if (help == 140)	repaintWindow(hWnd, hdc, ps, &area_third_floor, 6); 
			else if (help == 280)	repaintWindow(hWnd, hdc, ps, &area_second_floor, 5);
			else if (help == 420)	repaintWindow(hWnd, hdc, ps, &area_first_floor, 4);
			else if (help == 560)	repaintWindow(hWnd, hdc, ps, &area_zero_floor, 3);

			help += zmiana;				//dodaje do help zmiane, przez co w nastepnym wykonaniu winda zostanie narysowana kawalek dalej - tak tworzymy animacje
			break;	

		case TIMER_2:
			KillTimer(hWnd, TIMER_2);
			SetTimer(hWnd, TIMER_1, 50, NULL);
			break;

		case TIMER_3:
			KillTimer(hWnd, TIMER_3);
			SetTimer(hWnd, TIMER_1, 50, NULL);
			break;
		} 


    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }

    return 0;
}



// Procedura obsługi komunikatów dla okna informacji o programie.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)			//tego w ogole nie dotykalem
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
